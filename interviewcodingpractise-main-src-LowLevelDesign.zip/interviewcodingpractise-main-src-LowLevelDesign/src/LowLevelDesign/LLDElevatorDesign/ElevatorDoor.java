package LowLevelDesign.LLDElevatorDesign;

public class ElevatorDoor {

    public void openDoor(){
        System.out.println("Opening the Elevator door ");
    }

    public void closeDoor(){
        System.out.println("Closing the Elevator door");
    }

}
