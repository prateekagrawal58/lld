package LowLevelDesign.DesignPatterns.CompositeDesignPattern.Solution1WithCompositeDesign;

public interface FileSystem {
    public void ls();
}
