package LowLevelDesign.LLDCarRentalSystem.Product;

public class Bike extends Vehicle {
}
