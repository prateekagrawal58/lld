package LowLevelDesign.DesignBookMyShow.Enums;

public enum SeatCategory {

    SILVER,
    GOLD,
    PLATINUM;
}
