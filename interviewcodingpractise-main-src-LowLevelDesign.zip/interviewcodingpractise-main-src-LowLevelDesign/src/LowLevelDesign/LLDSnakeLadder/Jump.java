package LowLevelDesign.LLDSnakeLadder;

public class Jump {
    int start;
    int end;

    //getters and setters
}
